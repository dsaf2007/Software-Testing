
public class WarehouseImpl implements Warehouse {
	public void add(String product, int i) {}
	
	public int getInventory(String product) { 
			return 0; 
		}
	
	public boolean hasInventory(String product, int amount) { 
			return false; 
		}
	
	public void remove(String product, int i) { }
}
