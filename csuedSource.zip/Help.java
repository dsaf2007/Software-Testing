import java.io.*;

public class Help

{

  //***************************************************************************
  public static void General()
  {
  }

  //***************************************************************************
  public static void Command(char cmd)
  {
  }

} // EndClass Help 
